const i = 1
if (i) {
    console.log('test')
}